package com.example.myapplication;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.appsflyer.AppsFlyerConversionListener;

import java.util.Map;

public class MyAFListener implements AppsFlyerConversionListener {
    public String status;
    public Heave heave;
    public Context context;
    public boolean hasLoad = false;

    // 创建一个Handler实例，绑定到主线程的Looper
    Handler mainHandler = new Handler(Looper.getMainLooper());

    public MyAFListener(Heave heave, Context context){
        this.context = context;
        this.heave = heave;
    }
    @Override
    public void onConversionDataSuccess(Map<String, Object> map) {
        status = (String) map.get("af_status");
        Log.e("xxx","af success");

        Log.e("xxx1",status);
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                if(!hasLoad){
                    heave.toNext(status,context);
                    hasLoad = true;
                }

            }
        });

    }

    @Override
    public void onConversionDataFail(String s) {
        Log.e("xxx3",status);
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                heave.toNext("Organic",context);
            }
        });
    }

    @Override
    public void onAppOpenAttribution(Map<String, String> map) {

    }

    @Override
    public void onAttributionFailure(String s) {

    }
}
