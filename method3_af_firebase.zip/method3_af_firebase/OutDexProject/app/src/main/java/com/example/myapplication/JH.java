package com.example.myapplication;

import android.content.Context;
import android.util.Log;
import android.webkit.JavascriptInterface;

public class JH {
    private Context context;
    public JH(Context context){
        this.context = context;
    }
    @JavascriptInterface
    public void logEvent( String name,   String params) {

        Log.e("xxx","call by H5:"+name);

        LogManager.logEvent(name, params, context);
    }
}
