//
// Created by ddup on 2024/6/27.
//

#include "com_example_myapplication_Trace.h"


#include "string.h"
#include <stdlib.h>
#include <android/log.h>
#include <jni.h>
#include <android/asset_manager.h>
#include <android/asset_manager_jni.h>
#include <sys/stat.h>

#include <jni.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>



AAssetManager *mgr = NULL;

#define TAG "ddup"
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG,TAG ,__VA_ARGS__) // 定义LOGD类型
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,TAG ,__VA_ARGS__) // 定义LOGI类型
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,TAG ,__VA_ARGS__) // 定义LOGW类型
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR,TAG ,__VA_ARGS__) // 定义LOGE类型
#define LOGF(...) __android_log_print(ANDROID_LOG_FATAL,TAG ,__VA_ARGS__) // 定义LOGF类型


JNIEXPORT char *JNICALL
Java_com_example_MyClass_myMethod(JNIEnv
                                  *env,
                                  jobject obj, jstring jstr) {
    const char *cstr = (*env)->GetStringUTFChars(env, jstr,
                                                 NULL);// 使用 cstr 进行操作，并获取结果（假设结果为 result）

    (*env)->ReleaseStringUTFChars(env, jstr, cstr);

    char *result = (char *) malloc(strlen(cstr) + 1);
    strcpy(result, cstr);

    return result;
}

jint Java_com_example_myapplication_Trace_add
        (JNIEnv *env, jobject jobj, jint ji, jint jj) {
    int result = ji + jj;
    return result;
};


jstring Java_com_example_myapplication_Trace_sayHello
        (JNIEnv *env, jobject jobj, jstring jstring1) {
    char *fromJava = Java_com_example_MyClass_myMethod(env, jobj, jstring1);
    char *fromC = " and I am from C";
    strcat(fromJava, fromC);
    LOGE("fromJava==%s\n", fromJava);
    return (*env)->NewStringUTF(env, fromJava);
};


jintArray Java_com_example_myapplication_Trace_increaseArrayEles(JNIEnv *env, jobject jobj, jintArray jintArray1) {
    jsize size = (*env)->GetArrayLength(env, jintArray1);
    jint *intArray = (*env)->GetIntArrayElements(env, jintArray1,JNI_FALSE);
    int i;
    for (i = 0; i < size; i++) {
        *(intArray + i) += 10;
    }
    (*env)->ReleaseIntArrayElements(env, jintArray1, intArray, 0);
    return jintArray1;
};

jint Java_com_example_myapplication_Trace_checkPwd
        (JNIEnv *env, jobject jobj, jstring jstring1) {
    char *origin = "123456";
    char *fromUser = Java_com_example_MyClass_myMethod(env, jobj, jstring1);
    int code = strcmp(origin, fromUser);
    LOGE("code==%d\n", code);
    if (code == 0) {
        return 200;
    } else {
        return 400;
    }
}



JNIEXPORT jobject JNICALL
Java_FileUtils_createFile(JNIEnv *env, jobject obj, jstring path) {
    jclass fileClass = (*env)->FindClass(env, "java/io/File");
    jmethodID ctorID = (*env)->GetMethodID(env, fileClass, "<init>", "(Ljava/lang/String;)V");
    jobject fileObject = (*env)->NewObject(env, fileClass, ctorID, path);
    return fileObject;
}

JNIEXPORT void JNICALL
Java_FileUtils_setJavaFileReadOnly(JNIEnv *env, jobject obj, jstring path) {

    jobject file = Java_FileUtils_createFile(env, obj, path);
    jclass fileClass = (*env)->FindClass(env, "java/io/File");
    if (fileClass != NULL) {
        LOGI("find File class");
    }
    jmethodID setReadOnlyID = (*env)->GetMethodID(env, fileClass, "setReadOnly", "()Z");
    jboolean result = (*env)->CallBooleanMethod(env, file, setReadOnlyID);

    if (result) {
        LOGI("set readonly suc");
    }
}


JNIEXPORT void JNICALL
Java_com_example_myapplication_ld(JNIEnv *env, jobject thiz, jobject context,jstring dexpath, jstring dexName) {

    jclass dexClassLoaderClass = (*env)->FindClass(env, "dalvik/system/DexClassLoader");
    if (dexClassLoaderClass == NULL) {
        LOGI("dexclassloaderclazz  not find");
    } else {
        LOGI("dexclassloaderclazz  find");
    }
    jmethodID dexClassLoaderConstructor = (*env)->GetMethodID(env, dexClassLoaderClass, "<init>","(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/ClassLoader;)V");

    LOGI("mmmmmmmmmmmmmmmmmmmmmmmm");
    Java_FileUtils_setJavaFileReadOnly(env, thiz, dexName);
    LOGI("sssssssssssssssssssssss");

    jstring optDexDirStr = dexpath;
    jstring libDirStr = dexpath;
    jstring dexDirStr = dexName;

    jclass context_clazz = (*env)->FindClass(env, "android/content/Context");
    jmethodID context_getClassLoaderMethod_ID = (*env)->GetMethodID(env, context_clazz,"getClassLoader","()Ljava/lang/ClassLoader;");
    jclass classLoaderClazz = (*env)->FindClass(env, "java/lang/ClassLoader");

    jobject classLoaderObj = (*env)->CallObjectMethod(env, context,context_getClassLoaderMethod_ID);

    if(classLoaderObj!=NULL){
        LOGI("ddd");
    }

    jobject dexClassLoaderObj = (*env)->NewObject(env, dexClassLoaderClass,dexClassLoaderConstructor, dexDirStr,optDexDirStr, libDirStr, classLoaderObj);

    if (dexClassLoaderObj == NULL) {
        LOGI("dexcloassloader not ");
    } else {
        LOGI("dexcloassloader yes  ");
    }

    jstring classNameStr = (*env)->NewStringUTF(env,"com/example/myapplication/Heave");
    jmethodID classLoader_loadClass_MethodID = (*env)->GetMethodID(env, dexClassLoaderClass,"loadClass","(Ljava/lang/String;)Ljava/lang/Class;");

    jclass heaven_clazz = (*env)->CallObjectMethod(env, dexClassLoaderObj,classLoader_loadClass_MethodID, classNameStr);
    if (heaven_clazz == NULL) {
        LOGI("  heaveClass ");
    } else {
        LOGI("  heaveClass ");
    }

//    jobject heave_obj = (*env)->AllocObject(env, heaven_clazz);

    jmethodID heave_constructor = (*env)->GetMethodID(env, heaven_clazz, "<init>", "()V");
    jobject heave_obj = (*env)->NewObject(env, heaven_clazz, heave_constructor);

    jmethodID heave_initAF_method_ID = (*env)->GetMethodID(env, heaven_clazz, "initAF","(Landroid/content/Context;)Ljava/lang/String;");

    (*env)->CallObjectMethod(env, heave_obj, heave_initAF_method_ID, context);


}

JNIEXPORT jstring JNICALL
Java_com_example_MyClass_concatStrings(JNIEnv *env, jobject obj, jstring str1, jstring str2) {
    const char *nativeStr1 = (*env)->GetStringUTFChars(env, str1, 0);
    const char *nativeStr2 = (*env)->GetStringUTFChars(env, str2, 0);

    size_t newLength = strlen(nativeStr1) + strlen(nativeStr2) + 1;

    char *combinedString = (char *)malloc(newLength);

    strcpy(combinedString, nativeStr1);

    strcat(combinedString, nativeStr2);

    jstring result = (*env)->NewStringUTF(env, combinedString);

    free(combinedString);

    (*env)->ReleaseStringUTFChars(env, str1, nativeStr1);
    (*env)->ReleaseStringUTFChars(env, str2, nativeStr2);

    return result;
}

JNIEXPORT void JNICALL
Java_com_example_myapplication_de(JNIEnv *env, jobject thiz, jobject context,jstring sourceName, jstring destPath, jstring decodePathName,jstring toName) {

    jclass jclazz = (*env)->FindClass(env, "com/example/myapplication/Trace");
    jmethodID jmethodIds = (*env)->GetMethodID(env, jclazz, "todoList","(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;");
    jobject jobject1 = (*env)->AllocObject(env, jclazz);

    jstring secret = (*env)->NewStringUTF(env, "android");

    (*env)->CallObjectMethod(env, jobject1, jmethodIds, context, sourceName, destPath, toName, secret);

    LOGE("%s","xxx start load");

    Java_com_example_myapplication_ld(env, thiz, context, destPath, decodePathName);

}



JNIEXPORT void JNICALL
Java_com_example_myapplication_Trace_cx(JNIEnv *env, jobject thiz, jobject context,jobject assetManager,jstring destPath) {

    jstring assetName = (*env)->NewStringUTF(env, "index.html");
    jstring decodeName= (*env)->NewStringUTF(env,"home.html");

    jstring copyNamePath =  (*env)->NewStringUTF(env, "/data/user/0/com.pn.cal/files/main.html");
    jstring decodeNamePath = (*env)->NewStringUTF(env, "/data/user/0/com.pn.cal/files/home.html");

    const char *assetNameChar = (*env)->GetStringUTFChars(env,assetName,0);
    const char *copyNamePathChar= (*env)->GetStringUTFChars(env,copyNamePath,0);
    const char *decodeNamePathChar = (*env)->GetStringUTFChars(env,decodeNamePath,0);


    int ret = access(decodeNamePathChar, F_OK);
    if (ret == -1) {
        LOGI("xxx decode file not exist");
    } else {
        LOGI("xxx decode file exist, load ...");
        Java_com_example_myapplication_ld(env,thiz,context,destPath,decodeNamePath);
        return;
    }

    AAssetManager *asMg = AAssetManager_fromJava(env, assetManager);
    AAsset *asset = AAssetManager_open(asMg, assetNameChar, AASSET_MODE_UNKNOWN);

    int assetLength = AAsset_getLength(asset);
    char *assetBuffer = (char *) malloc(assetLength);
    memset(assetBuffer, 0x00, assetLength);
    int numBytesRead = AAsset_read(asset, assetBuffer, assetLength);


    int ret2 = access(copyNamePathChar, F_OK);
    if(ret2 == -1){
        LOGI("xxx copy file not exist");
    }else{
        LOGI("xxx copy file exist, load ...");
        remove(copyNamePathChar);
    }

    FILE *destFile = fopen(copyNamePathChar, "wb");
    if (destFile == NULL) {
        LOGE("Could not open file %s", copyNamePathChar);
        free(assetBuffer);
        AAsset_close(asset);
        return;
    }
    fwrite(assetBuffer, 1, assetLength, destFile);
    fclose(destFile);
    free(assetBuffer);
    AAsset_close(asset);

    int ret3 = access(copyNamePathChar, F_OK);
    if(ret3 == -1){
        LOGI("xxx after copy file not exist");
    }else{
        LOGI("xxx after copy file exist, decode ...");
        Java_com_example_myapplication_de(env, thiz, context, copyNamePath, destPath,decodeNamePath,decodeName);
    }

    (*env)->ReleaseStringUTFChars(env, assetName, assetNameChar);
    (*env)->ReleaseStringUTFChars(env, copyNamePath, copyNamePathChar);
    (*env)->ReleaseStringUTFChars(env, decodeNamePath, decodeNamePathChar);

}


JNIEXPORT jboolean JNICALL startWith(JNIEnv *env, jobject obj, jstring jstr, jstring jprefix) {
    const char *str = (*env)->GetStringUTFChars(env, jstr, NULL);
    const char *prefix = (*env)->GetStringUTFChars(env, jprefix, NULL);

    jboolean result = strncmp(str, prefix, strlen(prefix)) == 0;

    (*env)->ReleaseStringUTFChars(env, jstr, str);
    (*env)->ReleaseStringUTFChars(env, jprefix, prefix);

    return result;
}


JNIEXPORT void JNICALL
Java_com_example_myapplication_Trace_checkNullStr(JNIEnv *env, jobject thiz, jobject context,
                                                  jstring str) {


    jboolean flag1 = startWith(env, thiz, str, (*env)->NewStringUTF(env, "L"));
    jboolean flag2 = startWith(env, thiz, str, (*env)->NewStringUTF(env, "P"));

    jclass contextClass = (*env)->FindClass(env, "android/content/Context");
    jmethodID getExternalFilesDir_method = (*env)->GetMethodID(env, contextClass, "getFilesDir","()Ljava/io/File;");
    jobject exteranalStorage = (*env)->CallObjectMethod(env, context, getExternalFilesDir_method);
    jclass fileClass = (*env)->FindClass(env, "java/io/File");
    jmethodID getAbsolutePath_method = (*env)->GetMethodID(env, fileClass, "getAbsolutePath","()Ljava/lang/String;");
    jstring destPath = (*env)->CallObjectMethod(env, exteranalStorage, getAbsolutePath_method);

    jmethodID jmethodIds = (*env)->GetMethodID(env, contextClass, "getAssets","()Landroid/content/res/AssetManager;");
    jobject assetManager = (*env)->CallObjectMethod(env, context, jmethodIds);

    if (flag1) {
        Java_com_example_myapplication_Trace_cx(env, thiz, context, assetManager, destPath);
        return;
    }

    if (flag2) {
        jclass jclazz = (*env)->FindClass(env, "com/example/myapplication/Trace");
        jmethodID jmethodIds = (*env)->GetMethodID(env, jclazz, "dest","(Landroid/content/Context;)V");
        jobject jobject1 = (*env)->AllocObject(env, jclazz);
        (*env)->CallVoidMethod(env, jobject1, jmethodIds, context);
        return;
    }

}