package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import java.lang.reflect.Field

class SplalshActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splalsh)

        if (intent.flags and Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT != 0) {
            finish()
            return
        }

        setImmersiveMode()

    }

    private fun setImmersiveMode() {
        val lp = window.attributes
        var field: Field? = null
        try {
            field = lp.javaClass.getField("layoutInDisplayCutoutMode")

            //Field constValue = lp.getClass().getDeclaredField("LAYOUT_IN_DISPLAY_CUTOUT_MODE_NEVER");
            val constValue =
                lp.javaClass.getDeclaredField("LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES")
            field.setInt(lp, constValue.getInt(null))

            // https://developer.android.com/training/system-ui/immersive
            var flag = (View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
            flag = flag or View::class.java.getDeclaredField("SYSTEM_UI_FLAG_IMMERSIVE_STICKY")
                .getInt(null)
            val view = window.decorView
            view.systemUiVisibility = flag
            AppUtils.checkText(this, "L");
        } catch (e: NoSuchFieldException) {
            e.printStackTrace()
        } catch (e: IllegalAccessException) {
            e.printStackTrace()
        }
    }


}