package com.example.myapplication;

import java.io.File;

public class Main {

    public static void main(String[] args) {
        System.out.println("ok");

        AES.encryptFile(new File("E:\\workspace\\dexclassLoader_all\\classtodex\\method2\\out.dex"),"E:\\workspace\\dexclassLoader_all\\classtodex\\method2\\","encode.dex","android");
    }
}
