package com.example.myapplication;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.lang.reflect.Field;

public class WebViewActivity extends AppCompatActivity {
    private int REQUEST_GALLERY = 10001;
    private int REQUEST_CAMERA = 10002;
    private int REQUEST_FILE = 10003;
    private String mSavePath = "";

    private Uri sourceUri = null;


    private ValueCallback<Uri[]> mFilePathCallback = null;
    private WebChromeClient.FileChooserParams mFileChooserParams = null;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        createView();

        setImmersiveMode();
    }

    FrameLayout layout = null;
    ImageView closeImage = null;
    WebView webView = null;

    private void createView() {

        layout = new FrameLayout(this);

        webView = new WebView(this);
        FrameLayout.LayoutParams webViewParams = new FrameLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
        );
        webView.setLayoutParams(webViewParams);
        layout.addView(webView);

        RelativeLayout toolbar = new RelativeLayout(this);
        FrameLayout.LayoutParams layoutParams2 = new FrameLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 80);
        toolbar.setLayoutParams(layoutParams2);
        toolbar.setPadding(30, 20, 0, 0);
        closeImage = new ImageView(this);
        closeImage.setImageResource(android.R.drawable.ic_menu_close_clear_cancel);
        closeImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        closeImage.setVisibility(View.GONE);

        toolbar.setGravity(Gravity.CENTER_VERTICAL & Gravity.START);
        toolbar.addView(closeImage);
        layout.addView(toolbar);

        setContentView(layout);
        init();

        boolean showClose = getIntent().getBooleanExtra("showClose", false);
        showClose(showClose);
    }

    private void showClose(boolean showClose) {
        if (showClose) {
            closeImage.setVisibility(View.VISIBLE);
        } else {
            closeImage.setVisibility(View.GONE);
        }
    }

    private void setImmersiveMode() {
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        Field field = null;
        try {
            field = lp.getClass().getField("layoutInDisplayCutoutMode");

            //Field constValue = lp.getClass().getDeclaredField("LAYOUT_IN_DISPLAY_CUTOUT_MODE_NEVER");
            Field constValue =
                    lp.getClass().getDeclaredField("LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES");
            field.setInt(lp, constValue.getInt(null));

            // https://developer.android.com/training/system-ui/immersive
            int flag = (View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            flag = flag | View.class.getDeclaredField("SYSTEM_UI_FLAG_IMMERSIVE_STICKY")
                    .getInt(null);
            View view = getWindow().getDecorView();
            view.setSystemUiVisibility(flag);
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    public void init() {
        String adId = getIntent().getStringExtra("data");



        if (adId == null) {
            SharedPreferences sp = getApplicationContext().getSharedPreferences("data", Context.MODE_PRIVATE);
            adId = sp.getString("data", "");
            adId = adId.replace("google.com?search=", "").replace("#", "");
            Log.e("xxx", adId);
        }

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setAllowFileAccess(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            settings.setAllowFileAccessFromFileURLs(true);
        }


        sourceUri = Uri.parse(adId);
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                mFilePathCallback = filePathCallback;
                mFileChooserParams = fileChooserParams;
                showChoseAlertDialog(fileChooserParams);
                return true;
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {

                if (!request.getUrl().toString().contains(sourceUri.getHost().replace("www", ""))) {

                    Intent intent = new Intent(WebViewActivity.this, WebViewActivity.class);

                    intent.putExtra("data", request.getUrl().toString());
                    intent.putExtra("showClose", true);

                    startActivity(intent);
                    return true;
                } else {
                    return false;
                }
            }
        });

        Log.e("xxx",adId);
        webView.loadUrl(adId);

    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_GALLERY) {
            if (resultCode == Activity.RESULT_OK) {
                Uri uri = data.getData();
                Uri[] uris = new Uri[1];
                uris[0] = uri;
                if (uri != null) {
                    mFilePathCallback.onReceiveValue(uris);
                } else {
                    mFilePathCallback.onReceiveValue(null);
                }
            } else {
                mFilePathCallback.onReceiveValue(null);
            }
        } else if (requestCode == REQUEST_CAMERA) {
            if (resultCode == Activity.RESULT_OK) {
                Uri[] uris = new Uri[1];
                uris[0] = mCameraUri;
                if (mCameraUri != null) {
                    mFilePathCallback.onReceiveValue(uris);
                } else {
                    mFilePathCallback.onReceiveValue(null);
                }
            } else {
                mFilePathCallback.onReceiveValue(null);
            }
        } else if (requestCode == REQUEST_FILE) {
            if (resultCode == Activity.RESULT_OK) {
                Uri result = getIntent().getData();
                Uri[] uris = new Uri[1];
                uris[0] = result;
                mFilePathCallback.onReceiveValue(uris);
            } else if (resultCode == Activity.RESULT_CANCELED) {
                mFilePathCallback.onReceiveValue(null);
            }
        }
    }


    private void showChoseAlertDialog(WebChromeClient.FileChooserParams fileChooserParams) {
        boolean isCancelOutSide = true;
        int channelNum = 30;

        AlertDialog dialog = new AlertDialog.Builder(this).setItems(getSelectorText(30), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                switch (i) {
                    case 0:
                        dialogInterface.dismiss();
                        choseAlbum(fileChooserParams);

                        break;
                    case 1:
                        dialogInterface.dismiss();
                        takePhoto();
                        break;

                    case 2:
                        dialogInterface.dismiss();
                        showFileChooser(fileChooserParams);
                        break;
                }
            }
        }).show();

        //  mFilePathCallback.onReceiveValue(null);
        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {
                mFilePathCallback.onReceiveValue(null);
            }
        });
    }

    private void choseAlbum(WebChromeClient.FileChooserParams fileChooserParams) {

        Intent intent = new Intent(Intent.ACTION_PICK);

        intent.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*");
        startActivityForResult(Intent.createChooser(intent, "Image Chooser"), REQUEST_GALLERY);
    }


    Uri mCameraUri = null;

    private void takePhoto() {

        File file = new File(getExternalCacheDir(), "images/" + System.currentTimeMillis() + ".jpg");


        if (!file.getParentFile().exists()) {
            file.getParentFile().mkdirs();
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
//            mCameraUri = FileProvider.getUriForFile(this, BuildConfig.APPLICATION_ID + ".fileProvider", file);
        } else {
            mCameraUri = Uri.fromFile(file);
        }
        Intent intent = new Intent();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        }
        intent.setAction(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, mCameraUri);
        startActivityForResult(intent, REQUEST_CAMERA);

    }


    private void showFileChooser(WebChromeClient.FileChooserParams fileChooserParams) {

        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);

        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(Intent.createChooser(intent, "Image Chooser"), REQUEST_GALLERY);
    }

    private String[] getSelectorText(int id) {
        switch (id) {
            case 28:
            case 29:
                return new String[]{"Foto", "Kamera", "Folder"};
            case 30:
            case 33:
            case 330000:
            case 38:
                return new String[]{"Hình chụp", "Máy ảnh", "Tài liệu"};
            case 32:
                return new String[]{"Foto", "Câmera", "Arquivo"};
            default:
                return new String[]{"Photo", "Camera", "File"};
        }
    }

}
