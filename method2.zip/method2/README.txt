
通过B 面 addView往宿主Activity里面添加webview，
并使用javascriptInterface，添加上AF和firebase打点  