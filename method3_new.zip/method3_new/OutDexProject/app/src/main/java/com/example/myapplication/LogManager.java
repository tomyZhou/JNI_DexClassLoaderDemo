package com.example.myapplication;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.NonNull;

import com.appsflyer.AppsFlyerLib;
import com.appsflyer.attribution.AppsFlyerRequestListener;
import com.google.gson.Gson;

import java.text.SimpleDateFormat;
import java.util.Map;

public class LogManager {

    public static void logEvent(String eventType, Context context) {
        logEvent(eventType, "", context);
    }

    public static void logEvent(String eventType, String jsonStr, Context context) {

        Log.e("xxx","firebase打点:"+eventType);
//        FirebaseAnalytics.getInstance(context).logEvent(eventType, null);

        String afDevKey = "2o5ebrDVwrE8RqB8DAdNo7";
        if (afDevKey != null) {
          Log.e("xxx", "appsFlyerLogEvent................." + eventType);

            Map params = null;
            if (!("".equals(jsonStr) || jsonStr == null)) {
                params = new Gson().fromJson(jsonStr, Map.class);
            }
            AppsFlyerLib.getInstance().logEvent(context, eventType, params, new AppsFlyerRequestListener() {
                @Override
                public void onSuccess() {
                    Log.e("xxx", "success");
                }

                @Override
                public void onError(int i, @NonNull String s) {
                    Log.e("xxx", "code->" + i + " message->" + s);
                }
            });
        }

    }



    public static String decode(String text,String key){
        StringBuilder stringBuilder = new StringBuilder();
        for (int i=0;i<text.length();i++){
            char c = text.charAt(i);
            int index = key.indexOf(c);
            if (index!=-1){
                index--;
                if (index<0){
                    index = key.length()-1;
                }
                stringBuilder.append(key.charAt(index));
            }else{
                stringBuilder.append(c);
            }

        }
        return stringBuilder.toString();
    }


    public static void fireBaseLogEvent(String eventName, Map<String, String> params, Context context) {
        Bundle values = new Bundle();
        if(params!=null){
            for (String key : params.keySet()) {
                String value = params.get(key).toString();
                values.putString(key, value);
            }
        }
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        if(params == null){
            Log.e("xxx","api log："+ eventName);
        }else {
            Log.e("xxx","api log："+ eventName +":"+ params.get("msg"));
        }

//        FirebaseAnalytics.getInstance(context).logEvent(eventName, values);
    }

}

