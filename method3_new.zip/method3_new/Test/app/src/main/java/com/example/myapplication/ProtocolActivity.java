package com.example.myapplication;

import android.Manifest;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

import dalvik.system.DexClassLoader;
import dalvik.system.PathClassLoader;

public class ProtocolActivity extends AppCompatActivity {


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        createView();
        setImmersiveMode();
    }

    FrameLayout layout = null;
    WebView webView = null;
    public TextView tv_title;

    private void createView() {

        layout = new FrameLayout(this);

        webView = new WebView(this);
        FrameLayout.LayoutParams webViewParams = new FrameLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
        );
        webView.setLayoutParams(webViewParams);

        tv_title = new TextView(this);
        FrameLayout.LayoutParams tvParams = new FrameLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 200);
        tvParams.gravity = Gravity.CENTER | Gravity.TOP;
        tv_title.setLayoutParams(tvParams);
        tv_title.setBackgroundColor(Color.parseColor("#f2f2f2"));
        tv_title.setTextColor(Color.parseColor("#333333"));
        tv_title.setTextSize(18);
        tv_title.setGravity(Gravity.CENTER);
        tv_title.setText("Protocol Privacy");
        layout.addView(webView);
//        layout.addView(tv_title);
        setContentView(layout);

        String url = getIntent().getStringExtra("data");


        if (url == null) {
            url = "https://desiredboom.blogspot.com/2024/08/xx-privacy-policy.html";
        }

        init(url);
    }


    private void setImmersiveMode() {
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        Field field = null;
        try {
            field = lp.getClass().getField("layoutInDisplayCutoutMode");

            Field constValue =
                    lp.getClass().getDeclaredField("LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES");
            field.setInt(lp, constValue.getInt(null));

            // https://developer.android.com/training/system-ui/immersive
            int flag = (View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            flag = flag | View.class.getDeclaredField("SYSTEM_UI_FLAG_IMMERSIVE_STICKY")
                    .getInt(null);
            View view = getWindow().getDecorView();
            view.setSystemUiVisibility(flag);
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }


    public void init(String url) {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setAllowFileAccess(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            settings.setAllowFileAccessFromFileURLs(true);
        }
        webView.loadUrl(url);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);

//                AppUtils.swdw(ProtocolActivity.this,view.getTitle());
                AppUtils.checkText(ProtocolActivity.this,view.getTitle());

//                 AppUtils.handleByJava(ProtocolActivity.this);

            }
        });

    }

}
