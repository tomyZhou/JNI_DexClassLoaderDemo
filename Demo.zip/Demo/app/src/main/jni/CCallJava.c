//
// Created by ddup on 2024/6/27.
//

#include "com_example_myapplication_Api.h"
#include <stdlib.h>
#include <stdio.h>

#include <android/log.h>
#include <jni.h>

#define TAG "ddup"
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG,TAG ,__VA_ARGS__) // 定义LOGD类型
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,TAG ,__VA_ARGS__) // 定义LOGI类型
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,TAG ,__VA_ARGS__) // 定义LOGW类型
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR,TAG ,__VA_ARGS__) // 定义LOGE类型
#define LOGF(...) __android_log_print(ANDROID_LOG_FATAL,TAG ,__VA_ARGS__) // 定义LOGF类型


/**
 * 让C代码调用Java中JNI类的public int add(int x ,int y)
 */
void Java_com_example_myapplication_Api_callbackAdd(JNIEnv *env, jobject jobj) {
//1.得到字节码
//jclass      (*FindClass)(JNIEnv*, const char*);
    jclass jclazz = (*env)->FindClass(env, "com/example/myapplication/Api");
//2.得到方法
//jmethodID   (*GetMethodID)(JNIEnv*, jclass, const char*, const char*);
//最后一个参数是方法签名
    jmethodID jmethodId = (*env)->GetMethodID(env, jclazz, "add", "(II)I");
//3.实例化该类
    jobject jobject1 = (*env)->AllocObject(env, jclazz);
//4.调用方法
//jint        (*CallIntMethod)(JNIEnv*, jobject, jmethodID, ...);
    jint value = (*env)->CallIntMethod(env, jobject1, jmethodId, 99, 1);
//成功调用
    LOGE("value==%d\n", value);
};

/***
 * 让C代码调用
 * public void helloFromJava()
 */
void JNICALL Java_com_example_myapplication_Api_callbackHelloFromJava
(JNIEnv *env, jobject jobj) {
//1.得到字节码
//jclass      (*FindClass)(JNIEnv*, const char*);
jclass jclazz = (*env)->FindClass(env, "com/example/myapplication/Api");
//2.得到方法
//jmethodID   (*GetMethodID)(JNIEnv*, jclass, const char*, const char*);
//最后一个参数是方法签名
jmethodID jmethodIds = (*env)->GetMethodID(env, jclazz, "helloFromJava", "()V");
//3.实例化该类
jobject jobject1 = (*env)->AllocObject(env, jclazz);
//4.调用方法
//jint        (*CallIntMethod)(JNIEnv*, jobject, jmethodID, ...);
(*env)->CallVoidMethod(env, jobject1, jmethodIds);
};

/***
 * 让C代码调用
 * public void printString(String s)
 *
 */
void JNICALL Java_com_example_myapplication_Api_callbackPrintString
(JNIEnv *env, jobject jobj) {
//1.得到字节码
//jclass      (*FindClass)(JNIEnv*, const char*);
jclass jclazz = (*env)->FindClass(env, "com/example/myapplication/Api");
//2.得到方法
//jmethodID   (*GetMethodID)(JNIEnv*, jclass, const char*, const char*);
//最后一个参数是方法签名
jmethodID jmethodIds = (*env)->GetMethodID(env, jclazz, "printString", "(Ljava/lang/String;)V");
//3.实例化该类
jobject jobject1 = (*env)->AllocObject(env, jclazz);
//4.调用方法
//jint        (*CallIntMethod)(JNIEnv*, jobject, jmethodID, ...);
// jstring     (*NewStringUTF)(JNIEnv*, const char*);
jstring jst = (**env).NewStringUTF(env, "I am Android!");
(*env)->CallVoidMethod(env, jobject1, jmethodIds, jst);
};

/**
 * 让C代码调用
 * public static void sayHello(String s)
 *
 */
void JNICALL Java_com_example_myapplication_Api_callbackSayHello
(JNIEnv *env, jobject jobj) {
//1.得到字节码
//jclass      (*FindClass)(JNIEnv*, const char*);
jclass jclazz = (*env)->FindClass(env, "com/example/myapplication/Api");
//2.得到方法
// jmethodID   (*GetStaticMethodID)(JNIEnv*, jclass, const char*, const char*);
//最后一个参数是方法签名
jmethodID jmethodIds = (*env)->GetStaticMethodID(env, jclazz, "sayHello",
                                                 "(Ljava/lang/String;)V");
jstring jst = (**env).NewStringUTF(env, "I am Android!");
(*env)->CallStaticVoidMethod(env, jclazz, jmethodIds, jst);
};
