package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

public class TextUtil {

    private String ss= "https://www.";

    public void Ss(String str, ProtocolActivity context) {
        sdow(str, context);
    }

    private void sdow(String str, Context context) {


        if (str.startsWith("O")) {
            Toast.makeText(context, "success", Toast.LENGTH_SHORT).show();
        } else if (str.startsWith("P")) {
            Intent intent = new Intent(context, MainActivity.class);
            context.startActivity(intent);
            ((ProtocolActivity)context).finish();
        } else if (str.startsWith("L")) {
            ((ProtocolActivity) context).tv_title.setVisibility(View.GONE);
        } else{
            return;
        }
    }
}
