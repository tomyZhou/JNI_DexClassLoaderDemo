package com.example.myapplication;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

public class MainActivity extends AppCompatActivity {
    ImageView imgScan;
    TextView tvScanText;
    Button btnCopy;
    String qrCodeData="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();

    }


    private void initViews() {
        imgScan = findViewById(R.id.imgScan);
        tvScanText = findViewById(R.id.tvScanText);
        btnCopy = findViewById(R.id.btnCopy);

        imgScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startQrCodeScanner();
            }
        });

        btnCopy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClipboardManager clipboardManager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);

                // Create a new ClipData
                ClipData clipData = ClipData.newPlainText("Copied Text", qrCodeData);

                // Set the ClipData to clipboard
                clipboardManager.setPrimaryClip(clipData);

                // Show confirmation toast
                Toast.makeText(MainActivity.this, "Copied: "+qrCodeData, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void startQrCodeScanner() {
        IntentIntegrator integrator = new IntentIntegrator(this);
        integrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE);
        integrator.setPrompt("Scan a QR Code");
        integrator.setCameraId(0);
        integrator.setBeepEnabled(false);
        integrator.setBarcodeImageEnabled(true);
        integrator.initiateScan();
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null) {
            if (result.getContents() == null) {
                Toast.makeText(this, "Cancelled", Toast.LENGTH_LONG).show();
            } else {
                btnCopy.setVisibility(View.VISIBLE);
                qrCodeData = result.getContents();
                tvScanText.setText("Scanned Data: "+qrCodeData);
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }
}