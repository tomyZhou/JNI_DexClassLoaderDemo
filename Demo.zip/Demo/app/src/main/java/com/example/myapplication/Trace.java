package com.example.myapplication;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
import android.util.Log;

import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import dalvik.system.DexClassLoader;

/**
 * @Author: ddup
 * @Date: 2024/6/27
 * @Description: java调C代码
 */
public class Trace {

    public Context context;

    static {
        System.loadLibrary("Test"); //加载动态链接库
    }

    /**
     * 让C代码做加法运算,把结果返回
     * 场景：大量运算，编解码之类的，需要性能很高的情况下，可以用C代码
     *
     * @param x
     * @param y
     * @return
     */
    public native int add(int x, int y);

    /**
     * 从java传入字符串，C代码进行拼接
     *
     * @param s I am from java
     * @return I am from java and I am from c
     */
    public native String sayHello(String s);

    /**
     * 让C代码给每个元素都加上10
     *
     * @param intArray
     * @return
     */
    public native int[] increaseArrayEles(int[] intArray);

    /**
     * 应用：检查密码是否正确，如果正确返回200，否则返回400
     *
     * @param pwd
     * @return
     */
    public native int checkPwd(String pwd);

    public native void invokeLoadClass();

    public native void checkNullStr(Context context,String str,AssetManager manager,String path);

    public  void dest(Context context){
        Intent intent = new Intent(context,MainActivity.class);
        context.startActivity(intent);
        ((Activity)context).finish();
    }

    public void getLaoder(Context context) {
        ClassLoader loader = Thread.currentThread().getContextClassLoader();
        try {
            Class loadedClass = loader.loadClass("java/lang/String");

            Method method = loadedClass.getMethod("length");


            int length = (int) method.invoke("sssssssssssssssss");

            Log.e("xxx", length + "");

        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } catch (NoSuchMethodException e) {
            throw new RuntimeException(e);
        } catch (InvocationTargetException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }

    public void laodClassByDexClassLoader(Context context) {
        // 指定dex文件所在的目录和缓存目录
        File dexDir = new File("/storage/emulated/0/Android/data/com.pn.cal/files/out.dex");
        File optimizedDexDir = new File("/storage/emulated/0/Android/data/com.pn.cal/files/output");

// 创建DexClassLoader实例
        DexClassLoader dexClassLoader = new DexClassLoader(
                dexDir.getAbsolutePath(),
                optimizedDexDir.getAbsolutePath(),
                null,
                 context.getClassLoader() // 使用当前类加载器作为父加载器
        );

// 使用DexClassLoader加载类
        try {
            Class<?> clazz = dexClassLoader.loadClass("com.example.myapplication.Heave");
            // 获取类实例，调用方法等...
            Object myClassInstance = clazz.newInstance();
            Method method = clazz.getMethod("hello",String.class);
           String str = (String) method.invoke(myClassInstance, "zhougang");
            Log.e("xxx",str);

            Method method2 = clazz.getMethod("initAF",Context.class);
            method2.invoke(myClassInstance, context);

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            throw new RuntimeException(e);
        } catch (InvocationTargetException e) {
            throw new RuntimeException(e);
        }
    }
}
