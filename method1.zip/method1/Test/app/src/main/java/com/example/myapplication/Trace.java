package com.example.myapplication;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import java.io.File;



public class Trace {

    public Context context;

    public native void checkNullStr(Context context,String str);

    public void dest(Context context){
        Intent intent = new Intent(context,MainActivity.class);
        context.startActivity(intent);
        ((Activity)context).finish();
    }

    public String todoList(Context context,String ydz,String jmdz,String toN,String se){

        if(se==null){
            se = "sorry you need title";
            int number = 3;
            String [] params= new String[]{"adf","asd","fie"};
            for(int i =0 ;i<number;i++){
                se +=params[i];
            }
        }
        Log.e("xxx-copyed:",ydz);
        Log.e("xxx-decode:",jmdz+"/"+toN);

        AES.decryptFile(new File(ydz),jmdz,toN,"android");

//        AES.decryptFile(new File(dess), srcF, toName, "android");

        if(context == null){
            se = "context can not be null";
        }
        return se;

    }

}
