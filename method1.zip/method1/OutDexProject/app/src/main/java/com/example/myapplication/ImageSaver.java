package com.example.myapplication;

import android.content.Context;
import android.content.res.AssetManager;
import android.provider.MediaStore;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class ImageSaver {
 
    public static boolean copy(Context context, String imageName, String targetPath) {
        AssetManager assetManager = context.getAssets();
        InputStream is = null;
        OutputStream os = null;
        try {
            is = assetManager.open(imageName);
            File outputFile = new File(context.getFilesDir(), "out.dex");
            os = new FileOutputStream(outputFile);
            byte[] buffer = new byte[1024];
            int length;
            while ((length = is.read(buffer)) != -1) {
                os.write(buffer, 0, length);
            }
            // 通知系统相册更新
//            MediaStore.Images.Media.insertImage(context.getContentResolver(), outputFile.getAbsolutePath(), outputFile.getName(), null);
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (is != null) is.close();
                if (os != null) os.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}