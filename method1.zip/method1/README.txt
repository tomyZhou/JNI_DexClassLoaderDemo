

.so加密后放在asset目录里，代码启动，拷贝到私有目录下，解密。


加载so,判断开关。如果开关关闭，直接进到A面首页。如果开关打开，
copy asset中加密的文件到私有file目录下，AES解密。
最后使用dexclassloader加载。调用A包里的Webview打开B面网站，
AF打点代码在dex里。

使用d8打包，将调用工具类和Af所有的类都打进去。然后使用AES加密，
放在asset目录里。

