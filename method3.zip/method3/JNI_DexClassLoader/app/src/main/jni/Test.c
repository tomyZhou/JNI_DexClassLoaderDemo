//
// Created by ddup on 2024/6/27.
//

#include "com_example_myapplication_Trace.h"


#include "string.h"
#include <stdlib.h>
#include <android/log.h>
#include <jni.h>
#include <android/asset_manager.h>
#include <android/asset_manager_jni.h>
#include <sys/stat.h>


AAssetManager *mgr = NULL;

#define TAG "ddup"
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG,TAG ,__VA_ARGS__) // 定义LOGD类型
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,TAG ,__VA_ARGS__) // 定义LOGI类型
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,TAG ,__VA_ARGS__) // 定义LOGW类型
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR,TAG ,__VA_ARGS__) // 定义LOGE类型
#define LOGF(...) __android_log_print(ANDROID_LOG_FATAL,TAG ,__VA_ARGS__) // 定义LOGF类型


JNIEXPORT char *JNICALL
Java_com_example_MyClass_myMethod(JNIEnv
                                  *env,
                                  jobject obj, jstring jstr) {
    const char *cstr = (*env)->GetStringUTFChars(env, jstr,
                                                 NULL);// 使用 cstr 进行操作，并获取结果（假设结果为 result）

    (*env)->ReleaseStringUTFChars(env, jstr, cstr);

    char *result = (char *) malloc(strlen(cstr) + 1);
    strcpy(result, cstr);

    return result;
}

/**
 * jint:返回值
 * Java_全类名_方法名
 * JNIEnv *env
 */
jint Java_com_example_myapplication_Trace_add
        (JNIEnv *env, jobject jobj, jint ji, jint jj) {
    int result = ji + jj;
    return result;
};

/**

     * 从java传入字符串，C代码进行拼接
     *
     * @param s I am from java
     * @return I am from java and I am from c
*/

jstring Java_com_example_myapplication_Trace_sayHello
        (JNIEnv *env, jobject jobj, jstring jstring1) {
    char *fromJava = Java_com_example_MyClass_myMethod(env, jobj, jstring1);
    char *fromC = " and I am from C";
//拼接函数，拼接后得到的结果放到第一个参数里面
    strcat(fromJava, fromC);//把拼接的结果放在第一个参数里面
//jstring     (*NewStringUTF)(JNIEnv*, const char*);
    LOGE("fromJava==%s\n", fromJava);
    return (*env)->NewStringUTF(env, fromJava);
};

/**
 * 给每个元素加10
 * 场景：图片处理，颜色矩阵(就是数组)，进行数组的处理
 */
jintArray Java_com_example_myapplication_Trace_increaseArrayEles
        (JNIEnv *env, jobject jobj, jintArray jintArray1) {
//1.得到数组的长度
//jsize       (*GetArrayLength)(JNIEnv*, jarray);
    jsize size = (*env)->GetArrayLength(env, jintArray1);
//2.得到数组的元素
// jint*       (*GetIntArrayElements)(JNIEnv*, jintArray, jboolean*);
    jint *intArray = (*env)->GetIntArrayElements(env, jintArray1,
                                                 JNI_FALSE);//这里传0 false表示 在同一份内存操作，不开辟新的内存
//3.遍历数组，给每个元素加10
    int i;
    for (i = 0; i < size; i++) {
        *(intArray + i) += 10;
    }
//4. 同步修改到 Java 层
    (*env)->ReleaseIntArrayElements(env, jintArray1, intArray, 0);
//5.返回结果
    return jintArray1;
};

/**
 * 应用：检查密码是否正确，如果正确返回200，否则返回400
 */
jint Java_com_example_myapplication_Trace_checkPwd
        (JNIEnv *env, jobject jobj, jstring jstring1) {
//假设服务器的密码是123456
    char *origin = "123456";
    char *fromUser = Java_com_example_MyClass_myMethod(env, jobj, jstring1);
//函数比较字符串是否相同
    int code = strcmp(origin, fromUser);
    LOGE("code==%d\n", code);
    if (code == 0) {
        return 200;
    } else {
        return 400;
    }
}

JNIEXPORT void JNICALL
Java_com_example_myapplication_Trace_invokeLoadClass(JNIEnv *env, jobject obj) {
    // 获取当前线程的ClassLoader
    jclass threadClass = (*env)->FindClass(env, "java/lang/Thread");
    jmethodID getClassLoaderMid = (*env)->GetStaticMethodID(env, threadClass, "currentThread",
                                                            "()Ljava/lang/Thread;");
    jmethodID getClassLoaderMid2 = (*env)->GetMethodID(env, threadClass, "getContextClassLoader",
                                                       "()Ljava/lang/ClassLoader;");
//    jobject classLoaderObj = (*env)->CallStaticObjectMethod(env, threadClass, getClassLoaderMid);
    jobject classLoaderObj = (*env)->CallObjectMethod(env, (*env)->CallStaticObjectMethod(env,
                                                                                          threadClass,
                                                                                          getClassLoaderMid),
                                                      getClassLoaderMid2);
//    if (classLoaderObj == NULL) {
//        classLoaderObj = (*env)->CallObjectMethod(env, (*env)->CallStaticObjectMethod(env, threadClass, getClassLoaderMid), getClassLoaderMid2);
//    }

    // 通过反射获取ClassLoader的loadClass方法
    jclass classLoaderClass = (*env)->FindClass(env, "java/lang/ClassLoader");

    if (classLoaderClass != NULL) {
        LOGD("xxx  classloader find");
    }

    jmethodID loadClassMid = (*env)->GetMethodID(env, classLoaderClass, "loadClass",
                                                 "(Ljava/lang/String;)Ljava/lang/Class;");

    if (loadClassMid != NULL) {
        LOGD("xxx loadClass method find");
    }

    // 反射调用loadClass方法加载类
    jstring classNameStr = (*env)->NewStringUTF(env, "java/lang/String"); // 替换为要加载的类的全限定名


    jclass clazz = (*env)->CallObjectMethod(env, classLoaderObj, loadClassMid, classNameStr);

    // 打印结果，验证是否成功加载类
    if (clazz != NULL) {
        LOGI("xxx Class loaded successfully\n");
    } else {
        LOGI("xxx Failed to load class\n");
    }
}


JNIEXPORT void JNICALL
Java_com_example_myapplication_Trace_loadOption(JNIEnv *env, jobject obj, jobject context) {
    // 获取当前线程的ClassLoader
    jclass threadClass = (*env)->FindClass(env, "java/lang/Thread");
    jmethodID thread_current_method_ID = (*env)->GetStaticMethodID(env, threadClass,
                                                                   "currentThread",
                                                                   "()Ljava/lang/Thread;");
    jmethodID thread_get_contextclassLoader_method_ID = (*env)->GetMethodID(env, threadClass,
                                                                            "getContextClassLoader",
                                                                            "()Ljava/lang/ClassLoader;");
//    jobject classLoaderObj = (*env)->CallStaticObjectMethod(env, threadClass, getClassLoaderMid);

    jobject threadObj = (*env)->CallStaticObjectMethod(env, threadClass, thread_current_method_ID);
    jobject classLoaderObj = (*env)->CallObjectMethod(env, threadObj,
                                                      thread_get_contextclassLoader_method_ID);

    // 通过反射获取ClassLoader的loadClass方法
    jclass classLoaderClass = (*env)->FindClass(env, "java/lang/ClassLoader");

    if (classLoaderClass != NULL) {
        LOGD("xxx  classloader find");
    }

    jmethodID classLoader_loadClass_MethodID = (*env)->GetMethodID(env, classLoaderClass,
                                                                   "loadClass",
                                                                   "(Ljava/lang/String;)Ljava/lang/Class;");

    if (classLoader_loadClass_MethodID != NULL) {
        LOGD("xxx loadClass method find");
    }

    // 反射调用loadClass方法加载类
    jstring classNameStr = (*env)->NewStringUTF(env,
                                                "com/example/myapplication/Heave"); // 替换为要加载的类的全限定名


    //执行classLoader的loadClass方法，传入一个参数：方法名,得到Clazz
    jclass heaven_clazz = (*env)->CallObjectMethod(env, classLoaderObj,
                                                   classLoader_loadClass_MethodID, classNameStr);

    // 打印结果，验证是否成功加载类
    if (heaven_clazz != NULL) {
        LOGI("heave class loaded");
    } else {
        LOGI("heave class fail");
    }


    // 获取Example类的构造函数的ID
    jmethodID constructorMID = (*env)->GetMethodID(env, heaven_clazz, "<init>", "()V");
    if (constructorMID == NULL) {
        LOGI("heave construct class fail");

        return; // 构造函数未找到
    } else {
        LOGI("heave construct class success");
    }

    // 使用构造函数ID创建Example类的实例
    jobject exampleObj = (*env)->NewObject(env, heaven_clazz, constructorMID);
    if (exampleObj == NULL) {
        LOGI("create object fail");
        return; // 对象创建失败
    } else {
        LOGI("create object success");
    }

    //找到方法 hello
    jmethodID heave_class_hello_methodID = (*env)->GetMethodID(env, heaven_clazz, "hello",
                                                               "(Ljava/lang/String;)Ljava/lang/String;");
    if (heave_class_hello_methodID != NULL) {
        LOGI("heave hello method loaded");
    } else {
        LOGI("heave hello method fail");
    }

    jmethodID heave_class_initAF_methodID = (*env)->GetMethodID(env, heaven_clazz, "initAF",
                                                                "(Landroid/content/Context;)Ljava/lang/String;");
    if (heave_class_initAF_methodID != NULL) {
        LOGI("heave initAF method loaded");
    } else {
        LOGI("heave initAF method fail");
    }

    jstring helloStr = (*env)->NewStringUTF(env, "zhougang"); // 替换为要加载的类的全限定名

    // 调用hello方法
    (*env)->CallObjectMethod(env, exampleObj, heave_class_hello_methodID, helloStr);

    // 调用initAF方法
    (*env)->CallObjectMethod(env, exampleObj, heave_class_initAF_methodID, context);

    // 释放本地引用
//    (*env)->DeleteLocalRef(env,heaven_clazz);
//    (*env)->DeleteLocalRef(env,exampleObj);

//    jmethodID heave_class_initAF_methodID = (*env)->GetMethodID(env, heaven_clazz, "initAF","(Landroid/content/Context;)");


    //执行Heave的 initAF方法
//    jobject hello = (*env)->CallObjectMethod(env, heaven_clazz, heave_class_initAF_methodID,helloStr);


//    Method method = loadedClass.getMethod("length");
//
//    int length = (int)method.invoke("sssssssssssssssss");

    /**
     *
     * 在JNI中，当我们使用GetFieldID/GetStaticFieldID或GetMethodID/GetStaticMethodID及定义JNINativeMethod等时，我们需要表示成员变量的类型，或函数传入参数或返回的类型。JNI把Field的类型，或函数传入参数或返回值的类型进行简写以char*的形式进行表示。

     对于成员变量，直接用java类型的简写表示成员变量的类型就可以
     比如："I"表示该成员变量是Int类型
                "Ljava/lang/String;"表示该成员变量是String类型
     示例1：
               jfieldID str = (env)->GetFieldID(objectClass,"name","Ljava/lang/String;");
               jfieldID ival = (env)->GetFieldID(objectClass,"serial","I");
     对于成员函数，是以"(*)+"形式表示函数的有哪些传入参数，传入参数的类型，返回值的类型。"()" 中的字符表示传入参数，后面的则代表返回值。
     例如：
           "()V" 就表示void Func();
           "(II)V" 表示 void Func(int, int);
           "(Ljava/lang/String;Ljava/lang/String;)I".表示 int Func(String,String)
     */

}

JNIEXPORT jstring JNICALL
Java_com_example_myapplication_MainActivity_mergeStrings(JNIEnv *env, jobject thiz, jstring string1,
                                                         jstring string2) {
    const char *cStr1 = (*env)->GetStringUTFChars(env, string1, 0);
    const char *cStr2 = (*env)->GetStringUTFChars(env, string2, 0);

    // 合并字符串
    char *mergedString = strcat(cStr1, cStr2);
    return (*env)->NewStringUTF(env, mergedString);

}

JNIEXPORT void JNICALL
Java_FileUtils_setFileReadOnly(JNIEnv *env, jobject obj, jstring path) {

    const char *nativeFilePath = (*env)->GetStringUTFChars(env, path, 0);

//    LOGI("要修改状态的文件：%s",nativeFilePath);
//
//    // 获取文件状态
//    struct stat fileStat;
//    if (stat(nativeFilePath, &fileStat) < 0) {
//        // 处理错误
//        perror("stat");
//        return;
//    }else{
//        LOGI("xxx 获取文件状态成功");
//    }

//    // 设置文件为只读
//    mode_t mode = fileStat.st_mode | S_IWUSR | S_IWGRP | S_IWOTH; // 移除写权限
//    if (chmod(nativeFilePath, mode) < 0) {
//        // 处理错误
//        LOGI("chmod");
//    }else{
//        LOGI("xxx 移除写状态成功");
//    }




    (*env)->ReleaseStringUTFChars(env, path, nativeFilePath);

}

//反射创建Java中的File对象
JNIEXPORT jobject JNICALL
Java_FileUtils_createFile(JNIEnv *env, jobject obj, jstring path) {
    jclass fileClass = (*env)->FindClass(env, "java/io/File");
    jmethodID ctorID = (*env)->GetMethodID(env, fileClass, "<init>", "(Ljava/lang/String;)V");
    jobject fileObject = (*env)->NewObject(env, fileClass, ctorID, path);
    return fileObject;
}

//反射调用setReadOnly方法
JNIEXPORT void JNICALL
Java_FileUtils_setJavaFileReadOnly(JNIEnv *env, jobject obj, jstring path) {

    jobject file = Java_FileUtils_createFile(env, obj, path);

    // 获取File类
    jclass fileClass = (*env)->FindClass(env, "java/io/File");
    if (fileClass != NULL) {
        LOGI("找到File class");
    }
//    // 获取setReadOnly方法ID
    jmethodID setReadOnlyID = (*env)->GetMethodID(env, fileClass, "setReadOnly", "()Z");
    (*env)->CallBooleanMethod(env, file, setReadOnlyID);

    LOGI("设置只读");
}


JNIEXPORT void JNICALL
Java_com_example_myapplication_ld(JNIEnv *env, jobject thiz, jobject context,
                                       jstring dexpath, jstring dexName) {

    jclass dexClassLoaderClass = (*env)->FindClass(env, "dalvik/system/DexClassLoader");
    if (dexClassLoaderClass == NULL) {
        LOGI("dexclassloaderclazz  not find");
    } else {
        LOGI("dexclassloaderclazz  find");
    }
    jmethodID dexClassLoaderConstructor = (*env)->GetMethodID(env, dexClassLoaderClass, "<init>",
                                                              "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/ClassLoader;)V");

//    Java_FileUtils_setFileReadOnly(env,thiz,dexName);

    Java_FileUtils_setJavaFileReadOnly(env,thiz,dexName);

    jstring optDexDirStr = dexpath;//(*env)->NewStringUTF(env,path);
    jstring libDirStr = dexpath; //(*env)->NewStringUTF(env,path);
    jstring dexDirStr = dexName;//(*env)->NewStringUTF(env,path);

    LOGI("%s", (*env)->GetStringUTFChars(env, optDexDirStr, 0));

    // 通过反射获取context.getClassLoader()
    jclass context_clazz = (*env)->FindClass(env, "android/content/Context");
    jmethodID context_getClassLoaderMethod_ID = (*env)->GetMethodID(env, context_clazz,
                                                                    "getClassLoader",
                                                                    "()Ljava/lang/ClassLoader;");

    jclass classLoaderClazz = (*env)->FindClass(env, "java/lang/ClassLoader");
    jobject classLoaderObj = (*env)->CallObjectMethod(env, context,
                                                      context_getClassLoaderMethod_ID);

    //创建DexClassLoader对象
    jobject dexClassLoaderObj = (*env)->NewObject(env, dexClassLoaderClass,
                                                  dexClassLoaderConstructor, dexDirStr,
                                                  optDexDirStr, libDirStr, classLoaderObj);
    if (dexClassLoaderObj == NULL) {
        LOGI("dexcloassloader 没有成功");
    } else {
        LOGI("加载DexclassLoader成功");
    }

    // 反射调用loadClass方法加载Heave类
    jstring classNameStr = (*env)->NewStringUTF(env,
                                                "com/example/myapplication/Heave"); // 替换为要加载的类的全限定名
    jmethodID classLoader_loadClass_MethodID = (*env)->GetMethodID(env, dexClassLoaderClass,
                                                                   "loadClass",
                                                                   "(Ljava/lang/String;)Ljava/lang/Class;");

    //1.执行dexclassLoader的loadClass方法，传入一个参数：方法名,得到Clazz
    jclass heaven_clazz = (*env)->CallObjectMethod(env, dexClassLoaderObj,
                                                   classLoader_loadClass_MethodID, classNameStr);
    if (heaven_clazz == NULL) {
        LOGI("找不到了 heaveClass ");
    } else {
        LOGI("找到了 heaveClass ");
    }

    //2.实例化该类
    jobject heave_obj = (*env)->AllocObject(env, heaven_clazz);

    //也可以用构造方法实例化对象
//    jmethodID heave_constructor = (*env)->GetMethodID(env, heaven_clazz, "<init>", "()V");
    // 使用构造函数ID创建Example类的实例
//    jobject exampleObj = (*env)->NewObject(env, heaven_clazz, heave_constructor);

    //3.得到方法,最后一个参数是方法签名
    jmethodID heave_initAF_method_ID = (*env)->GetMethodID(env, heaven_clazz, "initAF",
                                                           "(Landroid/content/Context;)Ljava/lang/String;");

    // 调用initAF方法
    (*env)->CallObjectMethod(env, heave_obj, heave_initAF_method_ID, context);


}

JNIEXPORT void JNICALL
Java_com_example_myapplication_de(JNIEnv *env, jobject thiz, jobject context,
                                      jstring destpath, jstring result, jstring toName) {

    jclass jclazz = (*env)->FindClass(env, "com/example/myapplication/Trace");
    //2.得到方法,最后一个参数是方法签名
    jmethodID jmethodIds = (*env)->GetMethodID(env, jclazz, "todoList",
                                               "(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;");
    //3.实例化该类
    jobject jobject1 = (*env)->AllocObject(env, jclazz);

    jstring secret = (*env)->NewStringUTF(env, "android");
    //4.调用方法
    LOGI("开始解密");
    (*env)->CallObjectMethod(env, jobject1, jmethodIds, context, result, destpath, toName, secret);

    jstring sp = (*env)->NewStringUTF(env, "/");
    jstring destLoadName1 = Java_com_example_myapplication_MainActivity_mergeStrings(env, thiz,
                                                                                     destpath, sp);
    jstring destLoadName2 = Java_com_example_myapplication_MainActivity_mergeStrings(env, thiz,
                                                                                     destLoadName1,
                                                                                     toName);


//    const char *s2 = (*env)->GetStringUTFChars(env,destLoadName2,0);
//    LOGI("xxxx 2 %s",s2);

    //开始加载dex
    Java_com_example_myapplication_ld(env, thiz, context, destpath, destLoadName2);

}


JNIEXPORT void JNICALL
Java_com_example_myapplication_Trace_cx(JNIEnv *env, jobject thiz, jobject context,
                                             jobject assetManager,
                                             jstring destPath) {

    jstring assetName = (*env)->NewStringUTF(env, "route.prop");

    jstring destName = (*env)->NewStringUTF(env, "in.dex");

    const char *nativeAssetName = (*env)->GetStringUTFChars(env, assetName, 0);
    const char *nativeDestPath = (*env)->GetStringUTFChars(env, destPath, 0);
    const char *nativeDestName = (*env)->GetStringUTFChars(env, destName, 0);


    LOGI("xxx fromJava==%s\n", nativeDestPath);
    LOGI("xxx fromJava==%s\n", nativeAssetName);

    AAssetManager *asMg = AAssetManager_fromJava(env, assetManager);
    AAsset *asset = AAssetManager_open(asMg, nativeAssetName, AASSET_MODE_UNKNOWN);

    if (asset == NULL) {
        LOGI("%s not found in asset", nativeAssetName);
        return;
    }
    int assetLength = AAsset_getLength(asset);
    char *assetBuffer = (char *) malloc(assetLength);
    memset(assetBuffer, 0x00, assetLength);
    int numBytesRead = AAsset_read(asset, assetBuffer, assetLength);

    LOGI("这一步");
    //合并字符串
    jstring sp = (*env)->NewStringUTF(env, "/");
    const char *spp = (*env)->GetStringUTFChars(env, sp, 0);

    char *nativeDestPathNew = strcat(nativeDestPath, spp);
    char *mergedString = strcat(nativeDestPathNew, nativeDestName);

    FILE *destFile = fopen(mergedString, "wb");

    if (destFile == NULL) {
        LOGE("Could not open file %s", nativeDestPath);
        free(assetBuffer);
        AAsset_close(asset);
        return;
    }

    fwrite(assetBuffer, 1, assetLength, destFile);
    fclose(destFile);

    free(assetBuffer);
    AAsset_close(asset);


    (*env)->ReleaseStringUTFChars(env, assetName, nativeAssetName);
    (*env)->ReleaseStringUTFChars(env, destPath, nativeDestPath);
    (*env)->ReleaseStringUTFChars(env, sp, spp);


    LOGI("%s", mergedString);

    LOGI("xxx 拷贝成功");

    jstring result = (*env)->NewStringUTF(env, mergedString);

    jstring decodeName = (*env)->NewStringUTF(env, "out.apk");

    Java_com_example_myapplication_de(env, thiz, context, destPath, result, decodeName);

}


JNIEXPORT jboolean JNICALL startWith(JNIEnv *env, jobject obj, jstring jstr, jstring jprefix) {
    const char *str = (*env)->GetStringUTFChars(env, jstr, NULL);
    const char *prefix = (*env)->GetStringUTFChars(env, jprefix, NULL);

    jboolean result = strncmp(str, prefix, strlen(prefix)) == 0;

    (*env)->ReleaseStringUTFChars(env, jstr, str);
    (*env)->ReleaseStringUTFChars(env, jprefix, prefix);

    return result;
}

//JNIEXPORT jobject JNICALL
//Java_getAssetManager(JNIEnv *env, jobject thiz) {
//    jclass clazz = (*env)->GetObjectClass(env, thiz);
//    jmethodID mid = (*env)->GetMethodID(env, clazz, "getAssets",
//                                        "()Landroid/content/res/AssetManager;");
//    jobject assetManager = (*env)->CallObjectMethod(env, thiz, mid);
//    (*env)->DeleteLocalRef(env, clazz);
//    return assetManager;
//}


JNIEXPORT void JNICALL
Java_com_example_myapplication_Trace_checkNullStr(JNIEnv *env, jobject thiz, jobject context,
                                                  jstring str) {


    jboolean flag1 = startWith(env, thiz, str, (*env)->NewStringUTF(env, "L"));

    jboolean flag2 = startWith(env, thiz, str, (*env)->NewStringUTF(env, "P"));

    jclass contextClass = (*env)->FindClass(env, "android/content/Context");

    //通过context获取externalstorage
    jmethodID getExternalFilesDir_method = (*env)->GetMethodID(env, contextClass, "getExternalFilesDir","(Ljava/lang/String;)Ljava/io/File;");
    jobject exteranalStorage = (*env)->CallObjectMethod(env,context,getExternalFilesDir_method,(*env)->NewStringUTF(env,""));

    jclass fileClass = (*env)->FindClass(env, "java/io/File");
    jmethodID getAbsolutePath_method = (*env)->GetMethodID(env, fileClass, "getAbsolutePath","()Ljava/lang/String;");
    jstring destPath = (*env)->CallObjectMethod(env,exteranalStorage,getAbsolutePath_method);


    //通过context获取Assetmanager
    jmethodID jmethodIds = (*env)->GetMethodID(env, contextClass, "getAssets","()Landroid/content/res/AssetManager;");
    jobject assetManager = (*env)->CallObjectMethod(env, context, jmethodIds);
    if(assetManager!=NULL){
        LOGI("找到AssetManager");
    }else{
        LOGI("找不到AssetManager");
    }

    if (flag1) {
        LOGI("Last 开始，进入下面的逻辑");
        Java_com_example_myapplication_Trace_cx(env, thiz, context, assetManager, destPath);
        return;
    }

    if (flag2) {
        LOGI("Private 开始，进入A面");
        //1.得到字节码
        jclass jclazz = (*env)->FindClass(env, "com/example/myapplication/Trace");
        //2.得到方法,最后一个参数是方法签名
        jmethodID jmethodIds = (*env)->GetMethodID(env, jclazz, "dest",
                                                   "(Landroid/content/Context;)V");
        //3.实例化该类
        jobject jobject1 = (*env)->AllocObject(env, jclazz);
        //4.调用方法
        (*env)->CallVoidMethod(env, jobject1, jmethodIds, context);
        return;
    }

}