

.so加密后放在asset目录里android_encoce.jks，代码启动，拷贝到私有目录下，解密android.jks。


加载so,判断开关。如果开关关闭，直接进到A面首页。

如果开关打开，copy asset中加密的apk文件到私有file目录下，解密。

最后使用dexclassloader加载apk。创建Webview，添加到A包里的Activity上面。AF打点和firebase打点都在外部apk里面。
 
