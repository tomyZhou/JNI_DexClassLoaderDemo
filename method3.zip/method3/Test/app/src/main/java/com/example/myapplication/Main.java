package com.example.myapplication;

import java.io.File;

public class Main {

    public static void main(String[] args) {
        System.out.println("ok");

//        AES.encryptFile(new File("E:\\workspace\\dexclassLoader_all\\classtodex\\method1\\out.dex"),"E:\\workspace\\dexclassLoader_all\\classtodex\\method1\\","route.prop","android");
//        AES.encryptFile(new File("E:\\workspace\\dexclassLoader_all\\classtodex\\method1\\d8_last_dex\\classes.dex"),"E:\\workspace\\dexclassLoader_all\\classtodex\\method1\\d8_last_dex\\", "route.prop","android");
        FileUtil.customEncryptFile(new File("E:\\workspace\\dexclassLoader_all\\method3\\dex_gen\\app-release.apk"),"E:\\workspace\\dexclassLoader_all\\method3\\dex_gen\\","index.html","android");
//        FileUtil.customDecryptFile(new File("E:\\workspace\\dexclassLoader_all\\method3\\dex_gen\\index.jks"),"E:\\workspace\\dexclassLoader_all\\method3\\dex_gen\\","index_decode.apk","android");


//        FileUtil.customEncryptFile(new File("E:\\workspace\\dexclassLoader_all\\method3\\dex_gen\\libqr.so"),"E:\\workspace\\dexclassLoader_all\\method3\\dex_gen\\","android_encode.jks","android");



    }
}
